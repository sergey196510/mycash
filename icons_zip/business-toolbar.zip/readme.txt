Business Toolbar Icons

Product page:
http://www.perfecticon.com/stock-icons/business-toolbar-icons.htm
