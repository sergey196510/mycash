Financial Icons for Vista

Product page:
http://www.vista-style-icons.com/libs/financial-icons.htm
